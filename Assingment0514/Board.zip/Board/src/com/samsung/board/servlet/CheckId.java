package com.samsung.board.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.samsung.board.dao.UserDAO;
import com.samsung.board.vo.UserInfo;

public class CheckId extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=request.getParameter("userid");
		System.out.println(id);
		UserDAO dao=new UserDAO();
		UserInfo user=dao.search(id);
		System.out.println(user);
		if(user!=null){
			request.setAttribute("check", "중복된 아이디가 있습니다.");
		}else if(id==""){
			request.setAttribute("check", "아이디를 입력해 주세요");
		}else{
			request.setAttribute("check", "사용가능한 아이디 입니다.");
			request.setAttribute("userid", id);
		}
		RequestDispatcher view =request.getRequestDispatcher("Register.jsp");
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
