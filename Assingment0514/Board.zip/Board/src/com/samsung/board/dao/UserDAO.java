package com.samsung.board.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.samsung.board.util.JDBCUtil;
import com.samsung.board.vo.UserInfo;

public class UserDAO {

	static Connection con=null;
	static PreparedStatement ps=null;
	static ResultSet rs=null;
	
	public UserInfo login(UserInfo vo){
		UserInfo u=null;
		try {
			con=JDBCUtil.getConnection();
			String sql="select * from userinfo where userid=? and userpw=?";
			ps=con.prepareStatement(sql);
			ps.setString(1, vo.getUserId());
			ps.setString(2, vo.getUserPw());
			rs=ps.executeQuery();
			if(rs.next()){
				u=new UserInfo();
				u.setUserId(rs.getString("userid"));
				u.setUserPw(rs.getString("userpw"));
				u.setUserName(rs.getString("username"));
				u.setGender(rs.getString("gender"));
				u.setBirth(rs.getString("birth"));
				u.setEmail(rs.getString("email"));
				u.setPhone(rs.getString("phone"));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JDBCUtil.close(con, ps, rs);
		}
		return u;
	}
	
	public void register(UserInfo vo){
		try {
			con = JDBCUtil.getConnection();
			String sql="insert into userinfo values(?,?,?,?,?,?,?)";
			ps = con.prepareStatement(sql);
			ps.setString(1, vo.getUserId());
			ps.setString(2, vo.getUserPw());
			ps.setString(3, vo.getUserName());
			ps.setString(4, vo.getGender());
			ps.setString(5, vo.getBirth());
			ps.setString(6, vo.getEmail());
			ps.setString(7, vo.getPhone());
			ps.executeUpdate();
			System.out.println("========================");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JDBCUtil.close(con, ps);
		}
		
	}//register
	
	public UserInfo search(String id){
		UserInfo u=null;
		System.out.println(u+"======================");
		try {
			con=JDBCUtil.getConnection();
			String sql="select * from userinfo where userid=?";
			ps=con.prepareStatement(sql);
			ps.setString(1, id);
			rs=ps.executeQuery();
			if(rs.next()){
				u=new UserInfo(rs.getString("userid"),rs.getString("userpw"),rs.getString("username"),rs.getString("gender"),rs.getString("birth"),rs.getString("email"),rs.getString("phone"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			JDBCUtil.close(con, ps, rs);
		}
		return u;
	}
}
