package com.samsung.board.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.samsung.board.util.JDBCUtil;
import com.samsung.board.vo.BoardVO;

public class BoardDAO {
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	
public void addBoard(BoardVO vo, String today) {
		
		try {
			conn = JDBCUtil.getConnection();

			String sql = "";
			if (today.equals("")) {
				sql = "insert into board(seq, title, nickname, content, regdate, userid) "
						+ "values( (select nvl(max(seq), 0)+1 from board), ?, ?, ?, sysdate, 'guest')";
			} else {
				sql = "insert into board(seq, title, nickname, content, regdate, userid) "
						+ "values( (select nvl(max(seq), 0)+1 from board), ?, ?, ?, ?, 'guest')";
			}
			
			stmt = conn.prepareStatement(sql);
			
			if (today.equals("")) {
				stmt.setString(1, vo.getTitle());
				stmt.setString(2, vo.getNickname());
				stmt.setString(3, vo.getContent());

			} else {
				stmt.setString(1, vo.getTitle());
				stmt.setString(2, vo.getNickname());
				stmt.setString(3, vo.getContent());

				Date regdate = Date.valueOf(today);
				stmt.setDate(4, regdate);
			}
			
			int cnt = stmt.executeUpdate();

			System.out.println(cnt + "개가 정상 입력되었습니다.");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, stmt);
		}
	}

	public void updateBoard(BoardVO vo) {

		try {
			conn = JDBCUtil.getConnection();
			String sql = "update board set title=?, content=? where seq=?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getTitle());
			stmt.setString(2, vo.getContent());
			stmt.setInt(3, vo.getSeq());

			int cnt = stmt.executeUpdate();

			System.out.println(cnt + "개가 정상 입력 되었습니다.");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, stmt);
		}
		

	}

	public void deleteBoard(BoardVO vo) {


		try {
			conn = JDBCUtil.getConnection();
			String sql = "delete from board where seq = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getSeq());

			int cnt = stmt.executeUpdate();

			System.out.println(cnt + "개가 삭제 되었습니다.");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, stmt);
		}

	}

	// ResultSet 값을 적절히 처리해서 넘겨야 한다.
	public BoardVO getBoard(BoardVO vo) {
		BoardVO board = null;
		try {
			conn = JDBCUtil.getConnection();
			String sql = "select * from board where seq = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setInt(1, vo.getSeq());
			rs = stmt.executeQuery();
			
			
			if (rs.next()) {
				board = new BoardVO();
				board.setSeq(rs.getInt("seq"));
				board.setTitle(rs.getString("title"));
				board.setNickname(rs.getString("nickname"));
				board.setContent(rs.getString("content"));
				board.setRegdate(rs.getDate("regdate"));
				board.setUserid(rs.getString("userid"));
				board.setCnt(rs.getInt("cnt"));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return board;
	}

	// 모든 ResultSet 값을 적절히 처리해서 넘겨야 한다.
	public ArrayList<BoardVO> getBoardList(BoardVO vo) {
		ArrayList<BoardVO> boardArr = new ArrayList<>();
		BoardVO board = null;

		try {
			conn = JDBCUtil.getConnection();
			String sql = "";
			if(vo.getSearchCondition().equals("TITLE")){
				sql = "select * from board where title like '%' || ?|| '%' order by seq desc";
			}else if(vo.getSearchCondition().equals("CONTENT")){
				sql = "select * from board where content like '%' || ?|| '%' order by seq desc";
			}
			
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, vo.getSearchKeyword());
			
			rs = stmt.executeQuery();

			while (rs.next()) {
				board = new BoardVO();
				board.setSeq(rs.getInt("seq"));
				board.setTitle(rs.getString("title"));
				board.setNickname(rs.getString("nickname"));
				board.setContent(rs.getString("content"));
				board.setRegdate(rs.getDate("regdate"));
				board.setCnt(rs.getInt("cnt"));
				board.setUserid(rs.getString("userid"));
				boardArr.add(board);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JDBCUtil.close(conn, stmt, rs);
		}
		return boardArr;
	}
}
